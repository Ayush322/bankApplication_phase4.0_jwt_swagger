package com.fis.bankApplicationMicroservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import com.fis.bankApplicationMicroservices.model.Accounts;

public interface AccountsRepo extends CrudRepository<Accounts, Integer>, JpaRepository<Accounts, Integer> {
	@Query("select balance from Accounts where acctID = ?1")
	// this method find the balance from given account ID
	public int findBalanceByAcctID(int acctID) ;

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update Accounts set balance = balance+?2 where acctID=?1")
	//this method is annotated with transactional and modifying to update the account balance 
	//by adding specific amount
	public void saveBalanceByAcctID(int acctID, int balance);
	
	//this method is annotated with transactional and modifying to update the account balance 
	//by subtracting specific amount
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update Accounts set balance = balance-?2 where acctID=?1")
	public void withdrawAmountByAcctID(int acctID, int balance);

}
