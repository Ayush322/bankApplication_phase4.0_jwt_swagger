package com.fis.bankApplicationMicroservices.model;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
 
import org.junit.jupiter.api.Test;

import com.fis.bankApplicationMicroservices.model.Accounts;

public class AccountsTest {
	Accounts account = new Accounts();
	
	// test method for setting account ID
 
	@Test
	void setAcctIDTest() {
		account.setAcctID(124);
		assertEquals(124, account.getAcctID());
		
	}
	
	// test method for setting balance data
	@Test
	void setBalanceDataTest() {
		account.setBalance(50000);
		assertEquals(50000, account.getBalance());
	}

}
